 <main onclick="test_nav()">
    <main id="rest">
        <?php include('templates/base.php'); ?>
        <?php include('templates/details.php'); ?>
        <?php include('templates/coming.php'); ?>
        <?php include('templates/login.php'); ?>
        <?php include('templates/signin.php'); ?>
        <?php include('templates/profil.php'); ?>
        <?php include('templates/add.php'); ?>
        <?php include('templates/forgot.php'); ?>
        <?php include('templates/footer.php'); ?>
    </main>
</main>
