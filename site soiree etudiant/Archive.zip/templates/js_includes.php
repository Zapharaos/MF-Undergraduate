<script type="text/javascript" src="/../assets/JS/base.js"></script>
<script type="text/javascript" src="/../assets/JS/header.js"></script>
<script type="text/javascript" src="/../assets/JS/footer.js"></script>
<script type="text/javascript" src="/../assets/JS/profil.js"></script>
<script type="text/javascript" src="/../assets/JS/lang.js"></script>
<script type="text/javascript" src="/../assets/JS/lang_change.js"></script>
