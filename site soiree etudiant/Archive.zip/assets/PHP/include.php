<?php
    // including every needed php files 
    include 'db.php';
    include 'session.php';
    include 'langue.php';
    include 'signin.php';
    include 'login.php';
    include 'contact.php';
    include 'forgot.php';
    include 'reset.php';
    include 'profil.php';
    include 'add.php';
    include 'coming.php';
?>
