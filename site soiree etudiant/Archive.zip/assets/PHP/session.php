<?php
    // session is starting
    session_start();
?>
