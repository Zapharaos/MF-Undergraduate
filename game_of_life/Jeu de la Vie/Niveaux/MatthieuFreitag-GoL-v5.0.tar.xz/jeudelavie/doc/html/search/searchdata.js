var indexSectionsWithContent =
{
  0: "acdegijlmps",
  1: "g",
  2: "gij",
  3: "acdegilms",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Pages"
};

